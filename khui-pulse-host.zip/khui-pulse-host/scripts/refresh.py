"""Rebuild data.json. Replace fetch_*() with your real sources.
Keeps the same top-level keys the page expects:
daily, camp, aset, ads, gg, meta, biz, markets, targets, pin, ref, pdaily, chan
Anything you don't refresh is carried over from the existing data.json."""
import json, os, urllib.request, csv, io

def sheet_csv(url):
    with urllib.request.urlopen(url, timeout=60) as r:
        return list(csv.reader(io.StringIO(r.read().decode("utf-8"))))

def fetch_daily():
    # Example: a Google Sheet tab published as CSV, columns: date, ...metrics
    # rows = sheet_csv(os.environ["DAILY_CSV_URL"])[1:]
    # return [[r[0]] + [float(x or 0) for x in r[1:5]] for r in rows]
    return None  # None = keep existing

def main():
    with open("data.json") as f:
        data = json.load(f)
    new_daily = fetch_daily()
    if new_daily:
        data["daily"] = new_daily
    # same pattern for camp / aset / ads / biz ...
    with open("data.json", "w") as f:
        json.dump(data, f, separators=(",", ":"))

if __name__ == "__main__":
    main()
